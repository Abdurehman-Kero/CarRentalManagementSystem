const pool = require('./src/lib/db');

async function check() {
  try {
    const [cols] = await pool.query('DESCRIBE carimage');
    console.log('Columns in carimage:');
    console.table(cols);
    const [rows] = await pool.query('SELECT * FROM carimage');
    console.log('carimage rows:', rows);
  } catch (err) {
    console.error('Error:', err);
  } finally {
    await pool.end();
  }
}

check();
